# -*- coding: utf-8 -*-
"""
Created on Wed Feb 06 11:20:35 2013

@author: Scheidt
"""

fluke_5500E_01 = "fluke_5500E_01"
