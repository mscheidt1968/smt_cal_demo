# -*- coding: utf-8 -*-
"""
Created on Sun Apr 20 21:27:47 2014

@author: Scheidt
"""

import scipy as sci

c_comp_type = "comp_type"
c_comp_cable = "comp_cable"
standard_id = "standard_id"
standard_sub_id = "standard_sub_id"
device_specification = "device_specification"
ignore_plausibility = "ignore_plausibility"
expected_current = "expected_current"
expected_voltage = "expected_voltage"
no_leads_compensation = "no_leads_compensation"

if __name__=="__main__":
    pass
