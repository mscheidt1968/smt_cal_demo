# -*- coding: utf-8 -*-
"""
Created on Sun Apr 20 11:44:51 2014

@author: Scheidt
"""

import scipy as sci

from zmq import *

context = Context()


if __name__=="__main__":
    pass
