# -*- coding: utf-8 -*-
"""
Created on Sat May 31 11:58:29 2014

@author: Scheidt
"""

general_environment = set()

c_labor = "labor"
c_at_customer_site = "at_customer_site"

general_environment.add(c_labor)