# -*- coding: utf-8 -*-
"""
Created on Sat Oct 13 14:01:59 2012

@author: Scheidt
"""

#package initialization code goes here